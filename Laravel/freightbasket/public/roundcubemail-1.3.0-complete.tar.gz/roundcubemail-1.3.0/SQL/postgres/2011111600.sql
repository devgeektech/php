-- Updates from version 0.7-beta

ALTER TABLE "session" ALTER sess_id TYPE varchar(128);
