<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserCategoryController extends Controller
{
    //
}
